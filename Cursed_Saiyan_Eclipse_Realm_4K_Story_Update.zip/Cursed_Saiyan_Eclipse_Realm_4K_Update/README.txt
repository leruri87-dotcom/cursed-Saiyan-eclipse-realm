CURSED SAIYAN: ECLIPSE REALM — 4K STORY UPDATE

HOW TO PLAY
1. Extract this ZIP.
2. Open index.html in a recent desktop Chrome, Edge, or Firefox browser with internet access (Three.js is loaded from jsDelivr).
3. Use WASD or arrow keys to move, drag to rotate the camera, Shift to dash, Space to toggle flight, J to strike, K to fire a ki blast, L for Domain, and E to interact.
4. The graphics panel defaults to a 3840 x 2160 render buffer and a 999,000,000 theoretical triangle threshold. The triangle setting is a monitoring threshold only; it does not create that many triangles.

STORY
You and your friends are on a trip in a van when an impossible isekai airplane crashes into it. You wake in a Capsule Corp laboratory as mysterious bio-engineered inventions with Saiyan-like biology and strange energy powers. Explore the crash wreckage, find your friends, and uncover whether Capsule Corp rescued you—or planned for your arrival.

NOTES
- This is a browser prototype, not an Unreal Engine project or a finished AAA/console game.
- 4K is requested as the internal render-buffer size. Actual clarity depends on the display and graphics hardware; 4K rendering may be slow on tablets or lower-powered devices. Change resolution in the graphics panel if needed.
- The 999-million triangle budget is a theoretical ceiling/monitor threshold, not a realistic real-time target.
- The game uses Three.js from a CDN, so an internet connection is required to load the 3D engine.
